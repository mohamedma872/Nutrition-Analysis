//
//  API.swift
//  Nutrition Analysis
//
//  Created by Nada Kamel on 23/03/2021.
//

import Moya

public enum AppSecertKey {
    static  let appID = "4b2ff2b3"
    static  let appKey = "defdc8d11554ca3c845a7d5d5ef171ecw"
}

enum API {
    case recipeAnalysis(String, [String])
    case foodTextAnalysis(String)
}

extension API: TargetType {

    var baseURL: URL { return URL(string: "https://api.edamam.com/api/")!}
    
    var path: String {
        switch self {
        case .recipeAnalysis:
            return "nutrition-details"
        case .foodTextAnalysis:
            return "nutrition-data"
        }
    }
    
    var headers: [String:String]? {
       return ["Content-Type":"application/json"]
    }
    
    var method: Moya.Method {
        switch self {
        case .recipeAnalysis:
            return .post
        case .foodTextAnalysis:
            return .get
        }
    }
  
    var task: Task {
        var params = [String:String]()
        switch self {
        case .recipeAnalysis:
            params = ["app_id" : AppSecertKey.appID,
                      "app_key": AppSecertKey.appKey]
        case .foodTextAnalysis(let ingredientsEncoded):
            params = ["app_id" : AppSecertKey.appID,
                      "app_key": AppSecertKey.appKey,
                      "ingr": ingredientsEncoded]
        }
        switch self {
        case .recipeAnalysis:
            return .requestCompositeParameters(bodyParameters: bodyParameters, bodyEncoding: JSONEncoding.default, urlParameters: params)
        case .foodTextAnalysis:
            return .requestParameters(parameters: params , encoding: URLEncoding.default)
        }
    }
    // This is sample return data that you can use to mock and test your services
    var sampleData: Data {
        switch self {
        default:
            return Data()
        }
    }
    
    var bodyParameters: [String: Any] {
        switch self {
        case .recipeAnalysis(let title, let ingredients):
            return ["title": title, "ingr": ingredients]
        case .foodTextAnalysis(_):
            return ["":""]
        }
    }
}
